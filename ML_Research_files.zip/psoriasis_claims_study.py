#!/usr/bin/env python3
"""
Psoriasis biologic claims study: extract -> de-identify -> analyze.

USAGE
    python psoriasis_claims_study.py INPUT_FILE [--outdir results]
    INPUT_FILE may be .csv, .xlsx, a folder of .txt/.pdf reports, or one .txt/.pdf.

PRIVACY DESIGN
  * Whitelist approach: ONLY the six study fields (age is kept as a number, capped at 90) are ever kept. Names, DOB, MRN,
    member IDs, addresses, dates etc. are dropped the moment the file is read and
    are never written to disk or printed.
  * Each row gets a random study ID (no link back to the source, no key saved).
  * Free-text denial reasons are mapped to fixed categories (free text can leak PHI).
  * Rare insurance companies (< MIN_CELL claims) are collapsed into "Other".
  * Published summary tables suppress any cell < MIN_CELL (shown as "<11").
  * Keep the raw input OUTSIDE any shared/public folder. Share only the outputs.
"""
import argparse, re, secrets, sys
from pathlib import Path
import numpy as np
import pandas as pd
from scipy import stats
import statsmodels.formula.api as smf

MIN_CELL = 11  # small-cell suppression threshold (CMS convention)

# ---- 1. EDIT THIS to match your file's column headings (tabular input) ----------
COLUMN_MAP = {
    "insurance_type":    ["insurance type", "plan type", "payer type", "coverage type"],
    "insurance_company": ["insurance company", "payer", "insurer", "carrier", "plan name"],
    "treatment":         ["treatment", "drug", "medication", "biologic", "requested treatment"],
    "age":               ["age", "patient age", "age at request", "age at submission"],
    "claim_status":      ["claim status", "status", "decision", "outcome", "determination"],
    "denial_reason":     ["denial reason", "reason for denial", "reason", "denial code description"],
}

# Labels used to find fields inside text/PDF reports ("Label: value")
TEXT_LABELS = {k: v for k, v in COLUMN_MAP.items()}

# ---- 2. Standardization rules ---------------------------------------------------
BIOLOGIC_CLASSES = {
    "TNF inhibitor":   ["adalimumab", "humira", "hadlima", "hyrimoz", "cyltezo", "amjevita", "yusimry",
                        "etanercept", "enbrel", "erelzi", "eticovo", "infliximab", "remicade",
                        "inflectra", "renflexis", "avsola", "certolizumab", "cimzia"],
    "IL-17 inhibitor": ["secukinumab", "cosentyx", "ixekizumab", "taltz", "brodalumab", "siliq",
                        "bimekizumab", "bimzelx"],
    "IL-23 inhibitor": ["guselkumab", "tremfya", "risankizumab", "skyrizi", "tildrakizumab", "ilumya"],
    "IL-12/23 inhibitor": ["ustekinumab", "stelara", "wezlana", "selarsdi", "pyzchiva", "otulfi", "imuldosa"],
}
MEDICATIONS = {  # generic name -> brand/biosimilar keywords
    "Adalimumab": ["adalimumab", "humira", "hadlima", "hyrimoz", "cyltezo", "amjevita", "yusimry"],
    "Etanercept": ["etanercept", "enbrel", "erelzi", "eticovo"],
    "Infliximab": ["infliximab", "remicade", "inflectra", "renflexis", "avsola"],
    "Certolizumab": ["certolizumab", "cimzia"],
    "Secukinumab": ["secukinumab", "cosentyx"],
    "Ixekizumab": ["ixekizumab", "taltz"],
    "Brodalumab": ["brodalumab", "siliq"],
    "Bimekizumab": ["bimekizumab", "bimzelx"],
    "Guselkumab": ["guselkumab", "tremfya"],
    "Risankizumab": ["risankizumab", "skyrizi"],
    "Tildrakizumab": ["tildrakizumab", "ilumya"],
    "Ustekinumab": ["ustekinumab", "stelara", "wezlana", "selarsdi", "pyzchiva", "otulfi", "imuldosa"],
}
LIKELY_APPROVE, LIKELY_DENY = 0.70, 0.50   # thresholds for the "likely outcome" label
DENIAL_CATEGORIES = {
    "Prior authorization not obtained": ["prior auth", "no auth", "authorization not", "pa required"],
    "Step therapy / failed conventional therapy not documented":
        ["step therapy", "step-therapy", "conventional", "methotrexate", "phototherapy", "failed"],
    "Not medically necessary": ["medical necessity", "medically necessary", "not necessary", "criteria not met"],
    "Non-formulary / preferred drug required": ["formulary", "preferred", "biosimilar", "non-preferred"],
    "Incomplete documentation": ["documentation", "incomplete", "missing", "bsa", "pasi", "records"],
    "Out-of-network / coverage issue": ["network", "not covered", "eligib", "coverage terminated", "inactive"],
}

def norm_insurance_type(v):
    s = str(v).lower()
    if "medicaid" in s: return "Medicaid"
    if "medicare" in s: return "Medicare"
    if any(k in s for k in ["commercial", "private", "employer", "group", "ppo", "hmo", "marketplace", "aca"]):
        return "Commercial"
    if any(k in s for k in ["tricare", "va ", "veteran", "military"]): return "Military/VA"
    return "Other/Unknown"

def norm_age(v):
    """Numeric age in years. Ages >= 90 are capped at 90 (HIPAA Safe Harbor: 90+ is identifying)."""
    m = re.search(r"\d+(\.\d+)?", str(v))
    if not m: return np.nan
    a = float(m.group())
    if a < 0 or a > 120: return np.nan
    return min(int(a), 90)

AGE_BINS = [-1, 17, 34, 49, 64, 200]
AGE_LABELS = ["<18", "18-34", "35-49", "50-64", "65+"]

def norm_status(v):
    s = str(v).lower()
    if any(k in s for k in ["denied", "deny", "reject", "declin", "not approved"]): return "Denied"
    if any(k in s for k in ["approv", "paid", "covered", "authorized", "accept"]): return "Approved"
    return None  # unusable row

def norm_treatment(v):
    s = str(v).lower()
    for cls, names in BIOLOGIC_CLASSES.items():
        if any(n in s for n in names): return cls
    return "Other/Unclassified"

def norm_medication(v):
    s = str(v).lower()
    for generic, names in MEDICATIONS.items():
        if any(n in s for n in names): return generic
    return "Other/Unclassified"

def norm_denial(v, status):
    if status != "Denied": return "N/A (approved)"
    s = str(v).lower()
    for cat, keys in DENIAL_CATEGORIES.items():
        if any(k in s for k in keys): return cat
    return "Other / not specified"

# ---- 3. Reading input (PHI discarded immediately) --------------------------------
def _pick(df, names):
    cols = {c.lower().strip(): c for c in df.columns}
    for n in names:
        if n in cols: return cols[n]
    return None

def read_tabular(path):
    df = pd.read_csv(path, dtype=str) if path.suffix.lower() == ".csv" else pd.read_excel(path, dtype=str)
    out = {}
    for field, names in COLUMN_MAP.items():
        col = _pick(df, names)
        out[field] = df[col] if col else pd.Series([None] * len(df))
        if col is None and field != "denial_reason":
            print(f"WARNING: no column found for '{field}'. Edit COLUMN_MAP.", file=sys.stderr)
    return pd.DataFrame(out)  # every other column (PHI) is gone here

def read_report_text(path):
    if path.suffix.lower() == ".pdf":
        import pdfplumber
        with pdfplumber.open(path) as pdf:
            text = "\n".join((p.extract_text() or "") for p in pdf.pages)
    else:
        text = path.read_text(errors="ignore")
    rec = {}
    for field, labels in TEXT_LABELS.items():
        for lab in labels:
            m = re.search(rf"(?im)^\s*{re.escape(lab)}\s*[:\-]\s*(.+?)\s*$", text)
            if m: rec[field] = m.group(1); break
        rec.setdefault(field, None)
    return rec  # only the six fields survive; raw text is discarded

def load(input_path):
    p = Path(input_path)
    if p.is_dir():
        recs = [read_report_text(f) for f in sorted(p.iterdir()) if f.suffix.lower() in (".txt", ".pdf")]
        return pd.DataFrame(recs)
    if p.suffix.lower() in (".csv", ".xlsx", ".xls"): return read_tabular(p)
    return pd.DataFrame([read_report_text(p)])

# ---- 4. Build the de-identified analytic table ------------------------------------
def build_table(raw):
    t = pd.DataFrame({
        "insurance_type": raw["insurance_type"].map(norm_insurance_type),
        "insurance_company": raw["insurance_company"].fillna("Unknown").str.strip().str.title(),
        "medication": raw["treatment"].map(norm_medication),
        "biologic_class": raw["treatment"].map(norm_treatment),
        "age": raw["age"].map(norm_age),
        "claim_status": raw["claim_status"].map(norm_status),
    })
    t["denial_reason"] = [norm_denial(r, s) for r, s in zip(raw["denial_reason"], t["claim_status"])]
    t = t.dropna(subset=["claim_status"]).reset_index(drop=True)
    t["age_group"] = pd.cut(t["age"], bins=AGE_BINS, labels=AGE_LABELS).astype(object).fillna("Unknown")
    counts = t["insurance_company"].value_counts()
    rare = counts[counts < MIN_CELL].index
    t.loc[t["insurance_company"].isin(rare), "insurance_company"] = "Other (small payers pooled)"
    t.insert(0, "study_id", [secrets.token_hex(4) for _ in range(len(t))])  # random, unlinkable
    t["approved"] = (t["claim_status"] == "Approved").astype(int)
    return t

def suppress(df):
    return df.map(lambda x: f"<{MIN_CELL}" if isinstance(x, (int, np.integer)) and 0 < x < MIN_CELL else x)

# ---- 5. Three statistical analyses -------------------------------------------------
def chi_or_fisher(t, var):
    ct = pd.crosstab(t[var], t["claim_status"])
    chi2, p, dof, exp = stats.chi2_contingency(ct)
    test = "Chi-square"
    if (exp < 5).any() and ct.shape == (2, 2):
        _, p = stats.fisher_exact(ct); test = "Fisher exact"
    elif (exp < 5).any():
        test += " (WARNING: some expected counts < 5; interpret cautiously)"
    n = ct.values.sum()
    v = np.sqrt(chi2 / (n * (min(ct.shape) - 1))) if min(ct.shape) > 1 else np.nan
    rates = (t.groupby(var)["approved"].agg(["sum", "count"]))
    rates["approval_rate_%"] = (100 * rates["sum"] / rates["count"]).round(1)
    rates = rates.rename(columns={"sum": "approved_n", "count": "total_n"})
    return ct, rates, test, chi2, dof, p, v

def analysis_logit(t):
    d = t[(t["insurance_type"] != "Other/Unknown") & t["age"].notna()].copy()
    d["age_per_10y"] = d["age"] / 10.0
    model = smf.logit(
        "approved ~ C(insurance_type, Treatment('Commercial')) + age_per_10y"
        " + C(biologic_class, Treatment('TNF inhibitor'))", data=d).fit(disp=0)
    ci = np.exp(model.conf_int())
    res = pd.DataFrame({"odds_ratio": np.exp(model.params).round(2), "ci_low": ci[0].round(2),
                        "ci_high": ci[1].round(2), "p_value": model.pvalues.round(4)})
    res.index = [i.replace("C(", "").replace(", Treatment(", " vs ").replace("))[T.", " [").replace(")[T.", " [")
                 for i in res.index]
    return res.drop(res.index[0]), int(model.nobs)

def wilson(k, n, z=1.96):
    if n == 0: return (np.nan, np.nan)
    p = k / n; d = 1 + z**2 / n
    c = (p + z**2 / (2 * n)) / d
    h = z * np.sqrt(p * (1 - p) / n + z**2 / (4 * n**2)) / d
    return (max(0, c - h), min(1, c + h))

def combo_table(t):
    """Plan type x payer x medication: observed approval + model-predicted approval probability."""
    d = t[(t["insurance_type"] != "Other/Unknown") & (t["medication"] != "Other/Unclassified")].copy()
    obs = (d.groupby(["insurance_type", "insurance_company", "medication"])["approved"]
             .agg(approved_n="sum", total_n="count").reset_index())
    # model: approval ~ plan type + payer + medication, ridge-penalized so sparse cells stay stable
    f = "approved ~ C(insurance_type) + C(insurance_company) + C(medication)"
    import statsmodels.api as sm
    y, X = __import__("patsy").dmatrices(f, d, return_type="dataframe")
    fit = sm.GLM(y, X, family=sm.families.Binomial()).fit_regularized(alpha=0.002, L1_wt=0.0)
    pairs = d[["insurance_type", "insurance_company"]].drop_duplicates()
    grid = pairs.merge(pd.DataFrame({"medication": sorted(d["medication"].unique())}), how="cross")
    Xg = __import__("patsy").dmatrix(X.design_info, grid, return_type="dataframe")
    grid["predicted_approval_%"] = (100 * fit.predict(Xg)).round(1).values
    out = grid.merge(obs, how="left", on=["insurance_type", "insurance_company", "medication"])
    out[["approved_n", "total_n"]] = out[["approved_n", "total_n"]].fillna(0).astype(int)
    out["observed_approval_%"] = np.where(out.total_n >= MIN_CELL, (100 * out.approved_n / out.total_n.clip(lower=1)).round(1), np.nan)
    p = out["predicted_approval_%"] / 100
    out["likely_outcome"] = np.select([p >= LIKELY_APPROVE, p < LIKELY_DENY], ["Likely approved", "Likely denied"], "Uncertain")
    out["claims_n"] = out["total_n"].map(lambda n: f"<{MIN_CELL}" if n < MIN_CELL else n)  # small-cell suppression
    out = out.rename(columns={"insurance_type": "plan_type", "insurance_company": "payer"})
    out = out[["plan_type", "payer", "medication", "claims_n", "observed_approval_%", "predicted_approval_%", "likely_outcome"]]
    return out.sort_values(["plan_type", "payer", "predicted_approval_%"], ascending=[True, True, False]).reset_index(drop=True)

def best_worst(ct):
    rows = []
    for (pt, pay), g in ct.groupby(["plan_type", "payer"]):
        g = g.sort_values("predicted_approval_%", ascending=False)
        rows.append({"plan_type": pt, "payer": pay,
                     "most_likely_approved": f"{g.iloc[0].medication} ({g.iloc[0]['predicted_approval_%']}%)",
                     "most_likely_denied": f"{g.iloc[-1].medication} ({g.iloc[-1]['predicted_approval_%']}%)"})
    return pd.DataFrame(rows)

def run(t, outdir):
    out = []
    w = out.append
    w(f"N claims analyzed: {len(t)}   Approved: {t.approved.sum()}  Denied: {(1-t.approved).sum()}")
    w(f"Overall approval rate: {100*t.approved.mean():.1f}%\n")
    for title, var in [("ANALYSIS 1: Approval by INSURANCE TYPE", "insurance_type"),
                       ("ANALYSIS 2: Approval by BIOLOGIC CLASS", "biologic_class")]:
        ct, rates, test, chi2, dof, p, v = chi_or_fisher(t, var)
        w("=" * 70 + f"\n{title}\n" + "=" * 70)
        w(suppress(rates).to_string())
        w(f"\n{test}: chi2={chi2:.2f}, df={dof}, p={p:.4f}, Cramer's V={v:.2f}\n")
    w("=" * 70 + "\nANALYSIS 3: Multivariable logistic regression (outcome = approved)\n" + "=" * 70)
    try:
        res, n = analysis_logit(t)
        w(f"n = {n}. Reference groups: Commercial, TNF inhibitor; age is per 10-year increase. OR > 1 = higher odds of approval.")
        w(res.to_string() + "\n")
    except Exception as e:
        w(f"Model could not be fit (often too few claims or a category with no denials): {e}\n")
    w("=" * 70 + "\nDESCRIPTIVE: Age at submission and approval\n" + "=" * 70)
    ag = t[t.age_group != "Unknown"].groupby("age_group")["approved"].agg(["sum", "count"])
    ag = ag.reindex([l for l in AGE_LABELS if l in ag.index])
    ag["approval_rate_%"] = (100 * ag["sum"] / ag["count"]).round(1)
    w(suppress(ag.rename(columns={"sum": "approved_n", "count": "total_n"})).to_string())
    a1, a0 = t.loc[t.approved == 1, "age"].dropna(), t.loc[t.approved == 0, "age"].dropna()
    if len(a1) and len(a0):
        u, pu = stats.mannwhitneyu(a1, a0)
        w(f"Median age approved={a1.median():.0f}, denied={a0.median():.0f} (Mann-Whitney p={pu:.4f})\n")
    w("=" * 70 + "\nDESCRIPTIVE: Denial reasons (denied claims only)\n" + "=" * 70)
    dr = t[t.claim_status == "Denied"].groupby(["insurance_type", "denial_reason"]).size().rename("n").reset_index()
    w(suppress(dr.pivot(index="denial_reason", columns="insurance_type", values="n").fillna(0).astype(int)).to_string())
    out_dir = Path(outdir); out_dir.mkdir(parents=True, exist_ok=True)
    try:
        ct = combo_table(t)
        ct.to_csv(out_dir / "plan_payer_medication_table.csv", index=False)
        w("\n" + "=" * 70 + "\nTABLE: Medication most likely approved / denied for each plan type x payer\n" + "=" * 70)
        w(best_worst(ct).to_string(index=False))
        w("\n(Full ranked table: plan_payer_medication_table.csv. Predicted approval % comes from one regression on plan type,"
          f" payer and medication together, so it can be estimated even where observed claims are < {MIN_CELL}."
          " Because the model is additive, the medication ranking is similar across plans; large plan-specific"
          f" differences show up only in the observed columns when a cell has >= {MIN_CELL} claims.)")
    except Exception as e:
        w(f"\nPlan x payer x medication table could not be built: {e}")
    text = "\n".join(out)
    (out_dir / "analysis_results.txt").write_text(text)
    export = t.drop(columns=["approved"]).copy()
    export["age"] = export["age"].astype("Int64")  # whole years, no ".0"
    export.to_csv(out_dir / "deidentified_table.csv", index=False)
    print(text)
    print(f"\nSaved to {out_dir}/ : deidentified_table.csv, plan_payer_medication_table.csv, analysis_results.txt")

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("input"); ap.add_argument("--outdir", default="results")
    a = ap.parse_args()
    table = build_table(load(a.input))
    if table.empty: sys.exit("No usable rows found. Check COLUMN_MAP / report labels.")
    run(table, a.outdir)
